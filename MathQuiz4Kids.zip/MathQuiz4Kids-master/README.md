# MathQuiz4Kids
Math Quiz for Kids is a mobile game for kids to play by answering basic arithmetic questions.

Designed on Figma by Zuber Shemsu
Built with React Native by Zuber Shemsu & Yohannes Haile

![Simulator Screen Shot - iPhone 13 Pro Max - 2022-06-05 at 19 43 06](https://user-images.githubusercontent.com/58071246/172061413-73698472-ebe4-4c51-8618-725c1b687018.png)
![Simulator Screen Shot - iPhone 13 Pro Max - 2022-06-05 at 19 43 10](https://user-images.githubusercontent.com/58071246/172061414-56a93fba-326e-4059-bcce-615b97c303b7.png)
![Simulator Screen Shot - iPhone 13 Pro Max - 2022-06-05 at 19 43 15](https://user-images.githubusercontent.com/58071246/172061417-4ebaabaa-d7b2-484d-bc85-0942b05be6eb.png)
