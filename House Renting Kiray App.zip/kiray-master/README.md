# kiray
Kiray is an app that can be used to find and list rental houses.
![Simulator Screen Shot - iPhone 13 - 2022-07-10 at 12 59 38](https://user-images.githubusercontent.com/58071246/178140743-8d193e0e-b9d4-4b30-9a6a-2ed667970126.png)
![Simulator Screen Shot - iPhone 13 - 2022-07-10 at 12 59 50](https://user-images.githubusercontent.com/58071246/178140748-7f1931b2-4995-4894-ad5c-cbf50bebe29e.png)
![Simulator Screen Shot - iPhone 13 - 2022-07-10 at 13 00 23](https://user-images.githubusercontent.com/58071246/178140754-91a2cd6a-a733-48d9-a8ca-e5807a01f650.png)
![Simulator Screen Shot - iPhone 13 - 2022-07-10 at 13 00 49](https://user-images.githubusercontent.com/58071246/178140759-bfa68871-4588-44e7-86ac-750781d643bf.png)
